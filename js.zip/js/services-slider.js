// /js/services-slider.js
(() => {
  const section = document.querySelector('.services');
  if (!section) return;

  const slider  = section.querySelector('.services__slider');
  const prevBtn = section.querySelector('.services__arrow--prev');
  const nextBtn = section.querySelector('.services__arrow--next');
  const cards   = Array.from(slider?.querySelectorAll('.services__card') || []);
  if (!slider || cards.length === 0) return;

  // --- utwórz tor (track) i przenieś karty ---
  const track = document.createElement('div');
  track.className = 'services__track';
  cards.forEach(c => track.appendChild(c));
  slider.appendChild(track);

  let index = 0;

  const getStep = () => {
    const csSlider = getComputedStyle(slider);
    const gap = parseFloat(csSlider.gap || csSlider.columnGap || 0) || 0;
    const w = cards[0].getBoundingClientRect().width;
    return w + gap;
  };

  const apply = () => {
    const step = getStep();
    const x = -(index * step);
    track.style.transform = `translateX(${Math.round(x)}px)`;
    cards.forEach((c, i) => c.classList.toggle('is-active', i === index));
    if (prevBtn) prevBtn.disabled = index === 0;
    if (nextBtn) nextBtn.disabled = index === cards.length - 1;
  };

  // Strzałki
  prevBtn?.addEventListener('click', () => { if (index > 0) { index -= 1; apply(); } });
  nextBtn?.addEventListener('click', () => { if (index < cards.length - 1) { index += 1; apply(); } });

  // Klawiatura
  slider.tabIndex = 0;
  slider.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') { e.preventDefault(); nextBtn?.click(); }
    if (e.key === 'ArrowLeft')  { e.preventDefault(); prevBtn?.click(); }
  });

  // Swipe
  let dragging = false, startX = 0, dx = 0;
  const down = (x) => { dragging = true; startX = x; dx = 0; stopAuto(); track.style.transition = 'none'; };
  const move = (x) => {
    if (!dragging) return;
    dx = x - startX;
    const base = -(index * getStep());
    track.style.transform = `translateX(${Math.round(base + dx)}px)`;
  };
  const up = () => {
    if (!dragging) return;
    dragging = false;
    track.style.transition = ''; // wróć do CSS transition
    if (Math.abs(dx) > 30) {
      if (dx < 0 && index < cards.length - 1) index += 1;
      if (dx > 0 && index > 0)               index -= 1;
    }
    apply();
    startAuto();
  };

  slider.addEventListener('mousedown', e => down(e.clientX));
  window.addEventListener('mousemove', e => move(e.clientX));
  window.addEventListener('mouseup',   up);

  slider.addEventListener('touchstart', e => down(e.touches[0].clientX), { passive: true });
  slider.addEventListener('touchmove',  e => move(e.touches[0].clientX),  { passive: true });
  slider.addEventListener('touchend',   up);

  // Resize
  const ro = new ResizeObserver(apply);
  ro.observe(slider);

  // --- AUTOSLIDE (w środku IIFE) ---
  let autoTimer = null;
  const autoMs = 4000;

  const startAuto = () => {
    stopAuto();
    autoTimer = setInterval(() => {
      index = (index + 1) % cards.length; // pętla
      apply();
    }, autoMs);
  };

  const stopAuto = () => {
    if (autoTimer) {
      clearInterval(autoTimer);
      autoTimer = null;
    }
  };

  // Pauza na interakcję
  slider.addEventListener('mouseenter', stopAuto);
  slider.addEventListener('mouseleave', startAuto);
  slider.addEventListener('focusin',    stopAuto);
  slider.addEventListener('focusout',   startAuto);

  // Start
  apply();
  startAuto();
})();
