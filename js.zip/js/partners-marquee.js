/* ============================================================================
   PARTNERS MARQUEE — seamless triple-track (bez pustek, bez skoków)
   Oryginalny HTML:
     .partners__logos > .partners__row > (.partners__logo ...)

   Ustawienia:
     - Górny rząd jedzie w PRAWO  (speed > 0)
     - Dolny rząd jedzie w LEWO   (speed < 0), startuje +1000 ms
     - Nie wymaga zmian w SCSS/HTML (poza Twoją wysokością rzędu i gapem)
   ============================================================================ */
(() => {
  const CFG = {
    rowsSelector: '.partners__logos > .partners__row',
    speedsPxPerSec: [ +30, -30 ],   // [górny, dolny]; + => w prawo, - => w lewo
    startDelaysMs:  [    0, 1000 ],
    // pojedynczy segment (A) MUSI być co najmniej tak szeroki jak viewport rzędu,
    // inaczej widać tło — dokładamy porcje, aż A >= szerokość rzędu
    minSegmentWidthFactor: 1.0,
    rowHeightPx: 60,
    disableTouchDrag: true,
    respectReducedMotion: true
  };

  if (CFG.respectReducedMotion &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    return; // dostępność: brak animacji
  }

  const rows = Array.from(document.querySelectorAll(CFG.rowsSelector));
  if (!rows.length) return;

  // ---------- utils ----------
  const mod = (n, m) => ((n % m) + m) % m;

  function waitImages(root) {
    const imgs = Array.from(root.querySelectorAll('img'));
    if (!imgs.length) return Promise.resolve();
    const waits = imgs.map(img => {
      if (img.complete && img.naturalWidth > 0) return Promise.resolve();
      return new Promise(res => {
        const done = () => { img.removeEventListener('load', done); img.removeEventListener('error', done); res(); };
        img.addEventListener('load', done);
        img.addEventListener('error', done);
      });
    });
    // awaryjny timeout 2s – nigdy nie wisi
    return Promise.race([Promise.all(waits), new Promise(r => setTimeout(r, 2000))]);
  }

  // ---------- budowa rzędu: [A][A][A] + rAF ----------
  async function setupRow(rowEl, idx) {
    // snapshot oryginalnej sekwencji kafelków
    const seedHTML = rowEl.innerHTML.trim();
    if (!seedHTML) return null;

    // viewport techniczny — nic nie psuje layoutu
    rowEl.style.overflow = 'hidden';
    rowEl.style.position = 'relative';
    rowEl.style.height   = CFG.rowHeightPx + 'px';

    // pasek z trzema identycznymi segmentami
    const strip = document.createElement('div');
    Object.assign(strip.style, {
      display: 'flex',
      flexWrap: 'nowrap',
      height: '100%',
      willChange: 'transform'
    });

    // pojedynczy segment A (środkowy)
    const segMid = document.createElement('div');
    Object.assign(segMid.style, {
      display: 'flex',
      flexWrap: 'nowrap',
      height: '100%',
      flex: '0 0 auto'
    });
    segMid.innerHTML = seedHTML;

    // wstaw środkowy segment i czekaj na obrazki (prawdziwe wymiary)
    rowEl.innerHTML = '';
    strip.appendChild(segMid);
    rowEl.appendChild(strip);
    await waitImages(segMid);

    // jeśli A węższy niż viewport rzędu — dobuduj porcje seeda, aż A >= viewport
    const need = Math.max(1, rowEl.clientWidth * CFG.minSegmentWidthFactor);
    const seedChunk = segMid.innerHTML;
    let guard = 0;
    while (segMid.scrollWidth < need && guard++ < 200) {
      segMid.insertAdjacentHTML('beforeend', seedChunk);
    }

    // sklonuj A w lewo i w prawo → [A(left)][A(mid)][A(right)]
    const segLeft  = segMid.cloneNode(true);
    const segRight = segMid.cloneNode(true);

    strip.insertBefore(segLeft, strip.firstChild);
    strip.appendChild(segRight);

    // ustabilizuj obrazki (wys. rzędu)
    [segLeft, segMid, segRight].forEach(seg => {
      seg.querySelectorAll('img').forEach(img => {
        img.style.height = '100%';
        img.style.width  = 'auto';
        img.style.objectFit = 'contain';
        img.style.display = 'block';
        img.setAttribute('draggable', 'false');
      });
    });

    // zmierz i ZAMROŹ szerokość segmentu A (w px) – wszystkie 3 identyczne
    let W = segMid.getBoundingClientRect().width;
    [segLeft, segMid, segRight].forEach(seg => seg.style.width = W + 'px');

    // blokada gestów dotykowych w obrębie rzędu
    if (CFG.disableTouchDrag) {
      rowEl.addEventListener('touchmove', e => e.preventDefault(), { passive: false });
      rowEl.addEventListener('pointerdown', e => { if (e.pointerType === 'touch') e.preventDefault(); });
    }

    // parametry ruchu
    const v = CFG.speedsPxPerSec[idx] ?? CFG.speedsPxPerSec[0]; // + => prawo, - => lewo
    const delay = CFG.startDelaysMs[idx] ?? 0;
    let started = delay === 0;
    if (delay > 0) setTimeout(() => { started = true; }, delay);

    // stan przesunięcia (px); start ustawiamy tak, aby w kadrze był środkowy segment A
    let offset = 0;               // rośnie w czasie
    let base   = -W;              // pozycja środkowego A na starcie

    // reaguj na resize — jeśli viewport urośnie, dolej porcje do A, przelicz W i kontynuuj płynnie
    let rzTimer;
    const onResize = () => {
      clearTimeout(rzTimer);
      rzTimer = setTimeout(() => {
        const needNow = Math.max(1, rowEl.clientWidth * CFG.minSegmentWidthFactor);
        let added = false, guard2 = 0;
        while (segMid.scrollWidth < needNow && guard2++ < 200) {
          segMid.insertAdjacentHTML('beforeend', seedChunk);
          added = true;
        }
        if (added) {
          // zaktualizuj klony i szerokości
          segLeft.innerHTML  = segMid.innerHTML;
          segRight.innerHTML = segMid.innerHTML;
          W = segMid.getBoundingClientRect().width;
          [segLeft, segMid, segRight].forEach(seg => seg.style.width = W + 'px');
          // znormalizuj base tak, by zachować płynność
          base = -W + (mod(offset, W));
        }
      }, 120);
    };
    window.addEventListener('resize', onResize);

    return { strip, getW: () => W, getBase: () => base, setBase: b => (base = b), v, startedRef: () => started, getOff: () => offset, setOff: x => (offset = x) };
  }

  Promise.all(rows.map((r, i) => setupRow(r, i))).then(statesRaw => {
    const states = statesRaw.filter(Boolean);
    if (!states.length) return;

    let last = null;
    function tick(ts) {
      if (last == null) last = ts;
      const dt = (ts - last) / 1000;
      last = ts;

      for (const s of states) {
        if (!s.startedRef()) continue;

        const W = s.getW();
        if (W <= 0) continue;

        // zwiększamy „czasowy” offset, a pozycję liczymy modułowo wokół środkowego segmentu
        const off = s.getOff() + s.v * dt;
        s.setOff(off);

        const base = -W + mod(off, W); // środkowy segment zawsze w okolicy ekranu
        s.setBase(base);

        s.strip.style.transform = `translate3d(${base}px,0,0)`;
      }

      requestAnimationFrame(tick);
    }

    requestAnimationFrame(tick);
  });
})();
